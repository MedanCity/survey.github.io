﻿using System;
using System.IO;
using System.Windows.Forms;
using DevExpress.XtraRichEdit;
using DevExpress.XtraPrinting;
using DevExpress.Pdf;

namespace ListFiles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo(txtDirectory.Text );//Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles("*.*",SearchOption.AllDirectories); //Getting Text files
            string str = "";
            foreach (FileInfo file in Files)
            {
                str = str + file.DirectoryName + ", " + file.Name + Environment.NewLine;
            }
            txtList.Text =  str;


            //IEnumerable<string> GetFilesFromDir(string dir) =>
            //     Directory.EnumerateFiles(dir).Concat(
            //     Directory.EnumerateDirectories(dir)
            //              .SelectMany(subdir => GetFilesFromDir(subdir)));



            //// Get list of files in the specific directory.
            //// ... Please change the first argument.
            //string[] filesA = Directory.GetFiles(@"C:\Temp\", "*.*", SearchOption.AllDirectories);

            //// Display all the files.
            //foreach (string file in filesA)
            //{
            //    Console.WriteLine(file);
            //}
        }

        private void btnFilename_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo(txtDirectory.Text);//Assuming Test is your Folder
            //FileInfo[] Files = d.GetFiles("*.*", SearchOption.AllDirectories); //Getting Text files
            FileInfo[] Files = d.GetFiles("*.docx"); //Getting Text files
            string str = "";
            foreach (FileInfo file in Files)
            {
                
                str = str + file.Name + Environment.NewLine;
            }
            txtList.Text = str;
            //ConvertPDF3();
        }

        private void btnDirectory_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo(txtDirectory.Text);//Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles("*.*", SearchOption.AllDirectories); //Getting Text files
            string str = "";
            foreach (FileInfo file in Files)
            {
                str = str + file.DirectoryName + Environment.NewLine;
            }
            txtList.Text = str;
        }

        

        
       
        private void ConvertPDF3(FileInfo fileInfo) {
            RichEditDocumentServer wordProcessor = new RichEditDocumentServer();
            wordProcessor.LoadDocument(fileInfo.FullName , DocumentFormat.OpenXml);

            //Specify export options:
            PdfExportOptions options = new  PdfExportOptions();
            options.DocumentOptions.Author = "Faridah.Xie";
            options.Compressed = false;
            options.ImageQuality = PdfJpegImageQuality.Highest;



            //System.IO.Directory.CreateDirectory( fileInfo.Pat.FullName );


            string PdfFileName = fileInfo.FullName.Substring(0, fileInfo.FullName.Length - fileInfo.Extension.Length) + ".pdf";

            //Export the document to the stream:
            using (FileStream pdfFileStream = new FileStream(PdfFileName, FileMode.Create))
            {
                wordProcessor.ExportToPdf(pdfFileStream, options  );
            }

            //string directory = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, FilePath);

            //System.Diagnostics.Process.Start(@"c:\temp\Test_Dev.pdf");

            //using (DevExpress.Pdf.PdfDocumentProcessor  pdfDocumentProcessor = new DevExpress.Pdf.PdfDocumentProcessor())
            //{

            //    // Load a PDF document.
            //    pdfDocumentProcessor.LoadDocument(@"c:\temp\test_dev.pdf");

            //    // Specify printing, data extraction, modification, and interactivity permissions. 
            //    DevExpress.Pdf.PdfEncryptionOptions encryptionOptions = new DevExpress.Pdf.PdfEncryptionOptions();
            //    encryptionOptions.PrintingPermissions = PdfDocumentPrintingPermissions.Allowed;
            //    encryptionOptions.DataExtractionPermissions = PdfDocumentDataExtractionPermissions.NotAllowed;
            //    encryptionOptions.ModificationPermissions = PdfDocumentModificationPermissions.DocumentAssembling;
            //    encryptionOptions.InteractivityPermissions = PdfDocumentInteractivityPermissions.Allowed;

            //    // Specify the owner and user passwords for the document.  
            //    encryptionOptions.OwnerPasswordString = "OwnerPassword";
            //    encryptionOptions.UserPasswordString = "UserPassword";

            //    // Specify the 256-bit AES encryption algorithm.
            //    encryptionOptions.Algorithm = DevExpress.Pdf.PdfEncryptionAlgorithm.AES256;

            //    // Save the protected document with encryption settings.  
            //    pdfDocumentProcessor.SaveDocument(@"c:\temp\test_dev.pdf", new PdfSaveOptions() { EncryptionOptions = encryptionOptions });
            //}



        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo(txtDirectory.Text);//Assuming Test is your Folder
            //FileInfo[] Files = d.GetFiles("*.*", SearchOption.AllDirectories); //Getting Text files
            FileInfo[] Files = d.GetFiles("*.docx", cbIncludeDir .Checked ? SearchOption.AllDirectories:SearchOption.TopDirectoryOnly ); //Getting Text files
            string str = "";
            foreach (FileInfo file in Files)
            {
                if (System.IO.File.Exists (file.FullName)) {
                    if(MessageBox.Show(string.Format("This File {0} already exist, do you want to Override!", file.FullName),
                                       "Override", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        ConvertPDF3(file);
                    }
                }
                str = str + file.Directory + " - " + file.Name + Environment.NewLine;
            }
            txtList.Text = str;
            
        }
    }

}
